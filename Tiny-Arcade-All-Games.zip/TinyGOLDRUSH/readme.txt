TinyGOLDRUSH English version

*Install
Create a folder TinyGOLDRUSH on the MicroSD card. Copy the file.
TinyGOLDRUSH.bin
TinyGOLDRUSH.tsv
title.raw
stage.raw

*Sound volume
You can adjust the volume by moving the stick up and down on the title screen.

*Description
A random dungeon rogue-like game of 100-floors in all has appeared.
Let's operate the adventurer and gather the gold at the dungeon.
The game is a random dungeon of 100 floors. Everyone can easily and repeatedly play.
There is a treasure chest in the dungeon, among which 'weapons', 'potion' and 'gold' are included.
You can use weapons to increase attack power, promote HP recovery, release new characters and increase levels.
Each weapon has a durability value. Let's get a new weapon before that because it will be broken when it runs out.
You can choose whether or not to evolve as the character level reaches 100.
Evolution goes back to level 1, but it can be reborn to a stronger state than before, and by repeating it, you can steadily strengthen your character.
Easy operation. Move to the direction you want to go with the stick. Advance one turn with the button.
You can attack enemies with a stick. You can choose whether you want to go to the next floor when you are standing on the stairs.
The enemy will become stronger as you go forward, the more gold that comes out of the treasure box will be, so let's proceed.
A strong dragon appears every ten floors. Let's defeat the dragon!

DaimonSoftware 1st Develop section.
http://daimonsoft.info/kuran_kuran/

Tuchikure
http://www.ds-tuchikure.com/

Otoyoi Sound studio
https://www.youtube.com/channel/UCrITTAjO0z4MufpYG_cmEIA

TinyArcade
https://tinycircuits.com/
